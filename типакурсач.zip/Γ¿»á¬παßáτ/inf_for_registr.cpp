#include "inf_for_registr.h"
using namespace msclr::interop;

